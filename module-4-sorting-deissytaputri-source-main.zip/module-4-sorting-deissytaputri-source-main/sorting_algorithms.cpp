#include "sorting_algorithms.h"
#include <algorithm>
#include <chrono>

using Clock = std::chrono::high_resolution_clock;

void bubble_sort(std::vector<int>& data, Metrics& m) {
    int n = data.size();
    auto start = Clock::now();

    // TODO: implementasi Bubble Sort
    // Gunakan m.comparisons++ dan m.swaps++

    m.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}



void selection_sort(std::vector<int>& data, Metrics& m) {
    int n = data.size();
    auto start = Clock::now();

    // TODO: implementasi Selection Sort
    // Gunakan m.comparisons++ dan m.swaps++

    m.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}



void insertion_sort(std::vector<int>& data, Metrics& m) {
    int n = data.size();
    auto start = Clock::now();

    // TODO: implementasi Insertion Sort
    // Gunakan m.comparisons++ dan m.shifts++

    m.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}



void merge_sort(std::vector<int>& data, Metrics& m) {
    auto start = Clock::now();

    // TODO: panggil helper rekursif di sini
    // Gunakan m.comparisons++ dan m.recursive_calls++

    m.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}




void quick_sort(std::vector<int>& data, Metrics& m) {
    auto start = Clock::now();

    // TODO: panggil helper rekursif di sini
    // Gunakan m.comparisons++, m.swaps++, dan m.recursive_calls++

    m.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}



// TODO: tambahkan helper per-digit sort di sini jika perlu

void radix_sort(std::vector<int>& data, Metrics& m) {
    if (data.empty()) return;
    auto start = Clock::now();

    // TODO: implementasi Radix Sort
    // Gunakan m.array_accesses++

    m.time_ms = std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}